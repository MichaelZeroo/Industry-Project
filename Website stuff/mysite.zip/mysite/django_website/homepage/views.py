from django.shortcuts import render
# Create your views here.

def home(request):
    return render(request, 'homepage/home.html')

def aiEngine(request):
    return render(request, 'homepage/aiEngine.html')

def contactUs(request):
    return render(request, 'homepage/contactUs.html')
