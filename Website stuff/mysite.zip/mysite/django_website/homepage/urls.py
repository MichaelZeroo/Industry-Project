from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home-page'),
    path('aiEngine/', views.aiEngine, name='ai-Engine'),
    path('contactUs/', views.contactUs, name='contact-us'),
]
